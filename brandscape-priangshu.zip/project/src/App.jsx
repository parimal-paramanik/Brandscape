import React from 'react'
import Navbar from './Components/navbar/Navbar'
import Serach from './Components/Search/Serach'

const App = () => {
  return (
    <div className='container'>
      <Navbar/>
      <Serach/>
    </div>
    
  )
}

export default App
